# Android WebView App

Aplikasi Android sederhana yang menampilkan konten web menggunakan WebView dengan fitur lengkap.

## Fitur

- ✅ WebView dengan JavaScript enabled
- ✅ Support untuk navigasi back/forward
- ✅ Zoom controls
- ✅ Mixed content support (HTTP/HTTPS)
- ✅ Database dan DOM storage
- ✅ Cache support
- ✅ Error handling
- ✅ Modern Material Design UI

## Persyaratan Sistem

Sebelum membangun APK, pastikan Anda memiliki:

1. **Android Studio** (disarankan) atau
2. **Android SDK** + **Gradle** build tools
3. **Java Development Kit (JDK)** 8 atau lebih tinggi
4. **Android SDK API Level 34**
5. **Build tools version** 34.0.0

## Cara Build APK di Lokal

### Metode 1: Menggunakan Android Studio (Paling Mudah)

1. **Buka Android Studio**
2. **Pilih "Open an Existing Project"**
3. **Navigasi ke folder `android_webview` dan pilih folder tersebut**
4. **Tunggu Gradle sync selesai**
5. **Pilih Build Variant: "debug" untuk testing atau "release" untuk production**
6. **Klik Build > Build Bundle(s) / APK(s) > Build APK(s)**
7. **APK akan tersimpan di folder: `app/build/outputs/apk/debug/` atau `app/build/outputs/apk/release/`**

### Metode 2: Menggunakan Command Line

#### Windows:
```cmd
cd android_webview
gradlew.bat assembleDebug
```

#### macOS/Linux:
```bash
cd android_webview
./gradlew assembleDebug
```

#### Hasil Build:
- **Debug APK**: `app/build/outputs/apk/debug/app-debug.apk`
- **Release APK**: `app/build/outputs/apk/release/app-release.apk`

## Instalasi di Android

### Transfer APK ke Device:
1. **Copy file APK** dari folder build ke Android device
2. **Enable "Unknown Sources"** di Settings > Security
3. **Install APK** dengan mengklik file APK
4. **Aplikasi akan muncul** di launcher dengan nama "WebView App"

## Konfigurasi WebView

### Mengubah URL Default
Edit file `MainActivity.java`, method `loadDefaultUrl()`:
```java
private void loadDefaultUrl() {
    String defaultUrl = "https://website-anda.com";
    webView.loadUrl(defaultUrl);
}
```

### Menambahkan Fitur Browser
Tambahkan method ini di MainActivity untuk implementasi browser controls:

```java
public void reload() {
    webView.reload();
}

public void goForward() {
    if (webView.canGoForward()) {
        webView.goForward();
    }
}

public void goBack() {
    if (webView.canGoBack()) {
        webView.goBack();
    }
}
```

## Troubleshooting

### Build Error - SDK tidak ditemukan:
```bash
# Set Android SDK path (Linux/macOS)
export ANDROID_HOME=/path/to/Android/Sdk

# Set Android SDK path (Windows)
set ANDROID_HOME=C:\Users\YourName\AppData\Local\Android\Sdk
```

### Gradle Sync Error:
1. **Check internet connection**
2. **Update Android Studio** ke versi terbaru
3. **Clean project**: Build > Clean Project
4. **Rebuild project**: Build > Rebuild Project

### Runtime Error - Permission Denied:
- Pastikan **INTERNET permission** ada di AndroidManifest.xml
- Enable **Cleartext Traffic** untuk HTTP requests

## Struktur Proyek

```
android_webview/
├── app/
│   ├── src/main/
│   │   ├── java/com/example/webview/
│   │   │   └── MainActivity.java          # Activity utama dengan WebView
│   │   ├── res/
│   │   │   ├── layout/
│   │   │   │   └── activity_main.xml       # Layout UI
│   │   │   └── values/
│   │   │       └── strings.xml            # String resources
│   │   └── AndroidManifest.xml            # App configuration
│   ├── build.gradle                       # App-level build config
│   └── proguard-rules.pro                 # ProGuard configuration
├── build.gradle                           # Project-level build config
├── settings.gradle                        # Gradle settings
├── gradle.properties                      # Gradle properties
└── gradle/wrapper/                        # Gradle wrapper files
```

## Kustomisasi Lanjutan

### Mengubah Icon App:
1. **Ganti file di `res/mipmap-*/`**
2. **Update `android:icon`** di AndroidManifest.xml

### Menambahkan JavaScript Interface:
```java
// Tambahkan di setupWebView()
webView.addJavascriptInterface(new WebAppInterface(this), "Android");
```

### Custom WebViewClient:
```java
// Implementasi custom WebViewClient untuk handling errors
webView.setWebViewClient(new CustomWebViewClient());
```

## Security Notes

⚠️ **Peringatan Keamanan:**
- WebView mendukung JavaScript dan dapat menjalankan kode arbitrary
- Jangan load konten dari source yang tidak terpercaya
- Untuk production, enable HTTPS only
- Consider implementing Content Security Policy (CSP)

## Next Steps

1. **Add address bar** untuk input URL manual
2. **Implement bookmarks** untuk saved URLs  
3. **Add tab support** untuk multiple websites
4. **Implement download manager** untuk file downloads
5. **Add fullscreen support** untuk videos
6. **Implement history management**

---

**Dibuat dengan ❤️ untuk MiniMax Agent**

Untuk bantuan lebih lanjut, pastikan Android Studio dan SDK sudah terinstall dengan benar.